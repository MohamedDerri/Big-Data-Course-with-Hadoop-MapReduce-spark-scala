package defaultPackage

import java.io._
import scala.io.Source
import scala.math.random
import org.apache.spark._
import org.apache.spark.sql.{DataFrame, SQLContext}
import au.com.bytecode.opencsv.CSVParser
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SparkSession, functions}
import org.apache.spark.sql.functions._
//import spark.implicits._


object Bootstrap2 extends App{
  override def  main(args: Array[String]) {
    
    //creating spark config, spark context and spark session
    val conf = new SparkConf().setAppName("Spark and SparkSql").setMaster("local")
    val sc = new SparkContext(conf)
    
    val spark = SparkSession.builder()
      .master("local[1]")
      .appName("SparkByExamples.com")
      .getOrCreate();
    sc.setLogLevel("WARN")
  
//    Creating the printWriter to write result in our resultFile
    val writer = new PrintWriter(new 
        File("D:\\CAREER\\MIU\\Big Data\\Project2\\ProgramOutputStorage\\result.txt" ))
//    writer.write("Hello World")
    
    
    
//    reading the CSV file using sparkSession
    val data = spark.read.format("csv")
      .option("header", "true")
      .option("inferSchema", "true")
      .load("D:\\CAREER\\MIU\\Big Data\\Project2\\InputData\\CPSSW8.csv").drop("_c0").cache

    data.show()
    println()
        println("***************** DataInfo  ************************")
    println()
//    ***** Data Info*****
//    Distinct values for each Column
    println(" The Columns are: ")
    println(data.columns.mkString(", "))
    
    println()
    println("The unique values for each column:")
    data.drop("earnings").columns.map(s=>
      (s,data.select(s).dropDuplicates().collect()))
      .foreach(s=>{
        print(s._1+": ")
        s._2.foreach(print)
        println()
      })
    println()
    println("***************** (mean,var) of population and sample  ************************")
    println()
    
//    We're gonna first try to only study the earnings for people 
//      who's age is between 40 and 50 and who have education inferior or equal to 12 years
     
//      Getting the population ONLY the earnings !!!
    val men_between_40_50_eduSup_12=data
    .select("earnings")
    .filter(data("age") >=40 && data("age") <=50 && data("education") <=12)
    .collect()
    val length_population=men_between_40_50_eduSup_12.length
    println("population data's length : " +length_population)//8541
    
//    getting the sample out of the population
    val sample= sc.parallelize(sc.parallelize(men_between_40_50_eduSup_12)
    .takeSample(false, men_between_40_50_eduSup_12.length/4, 100)).cache
    val count_sample=sample.count()
    println("sample data's length : " +count_sample)//2135
    
//  computing the average of the earnings of the population
    var average_population_earnings=men_between_40_50_eduSup_12
    .map(i=>i.getDouble(0))
    .reduce((result,i)=>result+i)/men_between_40_50_eduSup_12.length
    println("This is the actual average earning of the population: "
        +average_population_earnings)//15.528408489400086
    
//    this is the variance 
    val variance_population =men_between_40_50_eduSup_12.map(e=>e.getDouble(0))
    .map(e=>Math.pow(e-average_population_earnings, 2))
    .reduce((result,i)=>result.+(i))/length_population
    println("this is the real variance "+  variance_population)//63.34738882894535
    
    println()
    println("***************** Bootstrap ************************")
    println()
//   Bootstrap Part
//    this variable is to sum the average of every sample created 
    var sum_earnings_bootstrap : Double=0.0
    
//    the Map is to keep track of the average of certain values
    var map_sumEarnings =Map[Int,(Double,Double)]()
    var tmp_variance : Double=0
    val max_samples_Bootstrap=1000//change meeee :3
    
    for(i <- 1 to max_samples_Bootstrap){
      
      sum_earnings_bootstrap+=sample.takeSample(true, count_sample.toInt,i)
      //the map is because each element is a row which I need to take it's earning      
      .map(i=>i.getAs[Double]("earnings"))
      .reduce((result,e)=>result+e)/count_sample
      
      
      if(Seq(1,20,50,100,200,400,600,800).contains(i)){
//        computing the variance
        tmp_variance=men_between_40_50_eduSup_12.map(e=>e.getDouble(0))
        .map(e=>Math.pow(e-sum_earnings_bootstrap/(i), 2))
        .reduce((result,i)=>result.+(i))/length_population
//        storing bothe the mean and variance
        map_sumEarnings +=(i -> (sum_earnings_bootstrap/(i),tmp_variance))
      }
    }
    
    val average_earnings_bootstrap=sum_earnings_bootstrap/max_samples_Bootstrap
    
    
    println("keeping track of the change of average and variance:")
    println(map_sumEarnings)
    println("Bootstrap average = "+average_earnings_bootstrap)//15.65195324002116
    val variance_Bootstrap=men_between_40_50_eduSup_12.map(e=>e.getDouble(0))
    .map(e=>Math.pow(e-average_earnings_bootstrap, 2))
    .reduce((result,i)=>result.+(i))/length_population
    println("Bootstrap variance = "+variance_Bootstrap)//63.36265213435099
  }
}