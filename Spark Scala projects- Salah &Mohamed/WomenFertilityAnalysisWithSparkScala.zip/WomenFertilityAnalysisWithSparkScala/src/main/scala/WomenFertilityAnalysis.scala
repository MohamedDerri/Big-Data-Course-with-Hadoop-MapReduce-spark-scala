import org.apache.spark.sql.SparkSession
import java.io._

object WomenFertilityAnalysis {

  def main(args: Array[String]): Unit = {

    // create a SparkSession object
    val spark = SparkSession.builder().appName("WomenFertilityAnalysis").master("local[*]").getOrCreate()

    // read the CSV file as a DataFrame
    val df = spark.read.format("csv").option("header", "true").load("/Users/mderri/Desktop/MIU courses/WomenFertilityAnalysisWithSparkScala/womenFertilityData.csv")

    // select the categorical and numerical variables and create a pair RDD
    val population = df.select("morekids", "age").rdd.map(row => (row.getString(0), row.getString(1).toDouble))

    // compute the mean and variance for each category
    val meanVariances = population.groupByKey().mapValues(values => {
      val mean = values.sum / values.size
      val variance = values.map(value => math.pow(value - mean, 2)).sum / values.size
      (mean, variance)
    })

    val pw1 = new PrintWriter(new File("output.txt"))
    pw1.write("Category Mean Variance\n")
    meanVariances.collect().foreach { case (category, (mean, variance)) =>
      pw1.write(s"$category $mean $variance\n")
    }
    pw1.write("----------------------------------------\n")

    // create a sample by taking 25% of the population without replacement
    val sample = population.sample(false, 0.25)

    // do 1000 iterations of bootstrapping
    val resampledMeansVariances = (1 to 1000).map { i =>
      // create a resampled data by taking 100% of the sample with replacement
      val resampledData = sample.sample(true, 1.0)

      // compute the mean and variance for each category
      val meanVariances = resampledData.groupByKey().mapValues(values => {
        val mean = values.sum / values.size
        val variance = values.map(value => math.pow(value - mean, 2)).sum / values.size
        (mean, variance)
      })

      // return the mean and variance for each category
      meanVariances.collect()
    }

    // compute the average mean and variance for each category
    val averageMeanVariances = resampledMeansVariances.reduce { (acc, x) =>
      acc.zip(x).map { case ((category, (mean1, variance1)), (_, (mean2, variance2))) =>
        (category, (mean1 + mean2, variance1 + variance2))
      }
    }.map { case (category, (meanSum, varianceSum)) =>
      (category, (meanSum / 1000, varianceSum / 1000))
    }

    // display the average mean and variance for each category
    pw1.write("Category Mean Variance\n")
    averageMeanVariances.foreach { case (category, (mean, variance)) =>
      pw1.write(s"$category $mean $variance\n")
    }
    pw1.close()
    // stop the SparkSession object
    spark.stop()
  }
}
